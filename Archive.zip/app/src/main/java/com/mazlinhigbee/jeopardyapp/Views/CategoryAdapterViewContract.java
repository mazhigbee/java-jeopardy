package com.mazlinhigbee.jeopardyapp.Views;

import com.mazlinhigbee.jeopardyapp.Models.Category;

/**
 * com.mazlinhigbee.jeopardyapp.Views
 * Created by: mhigbee
 * Date: 4/21/19 Time: 10:29 PM
 */
public interface CategoryAdapterViewContract {
    void categoryChosen(Category category);
}
